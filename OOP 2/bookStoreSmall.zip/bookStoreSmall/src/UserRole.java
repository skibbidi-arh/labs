

public enum UserRole {
    CUSTOMER, SELLER
}
